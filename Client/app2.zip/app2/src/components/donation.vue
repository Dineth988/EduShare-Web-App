<template>
  <div>
    <!-- Navigation Bar -->
    <nav>
      <div class="container nav-container">
        <div class="logo" style="content: 🎓">
          <span class="logo-text">EduShare</span>
        </div>
        <div class="nav-links">
          <a href="/home">Home</a>
          <a href="#">Donate</a>
          <a href="#">About</a>
          <a href="#">Contact</a>
        </div>
      </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
      <div class="container">
        <h1>Make a Difference Today</h1>
        <p>Your donations can change lives</p>
      </div>
    </section>

    <!-- Categories Section -->
    <section class="categories">
      <div class="container">
        <div class="categories-grid">
          <div
            v-for="category in categories"
            :key="category.name"
            class="category-card"
            @click="handleCategoryClick(category.name)"
            :class="{ selected: selectedCategory === category.name }"
          >
            <div class="category-icon">
              <img :src="category.icon" :alt="category.name" />
            </div>
            <h3 class="category-name">{{ category.name }}</h3>
          </div>
        </div>
      </div>
    </section>

    <!-- Donation Form -->
    <div class="container" v-if="showDonationForm">
      <form class="donation-form" @submit.prevent="handleSubmit">
        <!-- Item Details Section -->
        <div class="form-section">
          <h2>Item Details</h2>
          <input type="hidden" v-model="formData.resource_type" />
          <div class="form-row">
            <div class="form-group">
              <label for="item-name">Item Name</label>
              <input type="text" id="item-name" v-model="formData.title" required />
            </div>
            <div class="form-group">
              <label for="quantity">Quantity</label>
              <input type="number" id="quantity" v-model="formData.quantity" min="1" required />
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="condition">Condition</label>
              <select id="condition" v-model="formData.condition" required>
                <option value="">Select condition</option>
                <option value="new">New</option>
                <option value="like-new">Like New</option>
                <option value="good">Good</option>
                <option value="fair">Fair</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" v-model="formData.description" required></textarea>
          </div>
          <div class="form-group">
            <label>Image</label>
            <div class="image-input-options">
              <button
                type="button"
                @click="showImageUpload = true"
                :class="{ active: showImageUpload }"
              >
                Upload Image
              </button>
              <button
                type="button"
                @click="showImageUpload = false"
                :class="{ active: !showImageUpload }"
              >
                Enter Image URL
              </button>
            </div>

            <div v-if="showImageUpload">
              <input
                type="file"
                @change="handleImageUpload"
                style="display: none"
                id="image-upload"
                accept="image/*"
              />
              <div class="image-upload" @click="document.getElementById('image-upload').click()">
                <template v-if="!formData.image_link">
                  <i
                    class="fas fa-cloud-upload-alt"
                    style="font-size: 2rem; color: #2462eb; margin-bottom: 0.5rem"
                  ></i>
                  <p>Click to upload or drag and drop</p>
                  <p style="font-size: 0.8rem; color: #999">PNG, JPG, GIF up to 5MB</p>
                </template>
                <template v-else>
                  <img
                    :src="formData.image_link"
                    alt="Preview"
                    style="max-width: 200px; max-height: 200px"
                  />
                </template>
              </div>
            </div>

            <div v-else class="form-group">
              <label for="image-url">Image URL</label>
              <input
                type="url"
                id="image-url"
                v-model="formData.image_link"
                placeholder="https://example.com/image.jpg"
              />
            </div>
          </div>
        </div>

        <!-- Delivery Method Section -->
        <div class="form-section">
          <h2>Delivery Method</h2>
          <div class="delivery-options">
            <div
              class="delivery-option"
              :class="{ selected: formData.deliveryMethod === 'self-ship' }"
              @click="formData.deliveryMethod = 'self-ship'"
            >
              <div class="radio-container">
                <input
                  type="radio"
                  id="self-ship"
                  v-model="formData.deliveryMethod"
                  value="self-ship"
                />
                <label for="self-ship">Self Ship</label>
              </div>
              <p class="option-description">I will arrange shipping myself</p>
            </div>
            <div
              class="delivery-option"
              :class="{ selected: formData.deliveryMethod === 'partner-pickup' }"
              @click="formData.deliveryMethod = 'partner-pickup'"
            >
              <div class="radio-container">
                <input
                  type="radio"
                  id="partner-pickup"
                  v-model="formData.deliveryMethod"
                  value="partner-pickup"
                />
                <label for="partner-pickup">Partner Pickup</label>
              </div>
              <p class="option-description">Our partners will pick up the items</p>
            </div>
          </div>
        </div>

        <!-- Additional Options Section -->
        <div class="form-section">
          <h2>Additional Options</h2>
          <div class="toggle-group">
            <label class="toggle-switch">
              <input type="checkbox" v-model="formData.isRecurring" />
              <span class="slider"></span>
            </label>
            <span>Make this recurring</span>
          </div>
          <div class="form-group">
            <label for="special-instructions">Special Instructions</label>
            <textarea id="special-instructions" v-model="formData.specialInstructions"></textarea>
          </div>
        </div>

        <!-- Form Buttons -->
        <div class="form-actions">
          <button type="button" class="btn btn-secondary" @click="resetForm">Cancel</button>
          <button type="submit" class="btn btn-primary" :disabled="isSubmitting">
            {{ isSubmitting ? 'Submitting...' : 'Complete Donation' }}
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

// Categories data
const categories = [
  {
    name: 'Printed Materials',
    icon: 'https://img.icons8.com/?size=100&id=38854&format=png&color=228BE6',
  },
  {
    name: 'Technology',
    icon: 'https://img.icons8.com/?size=100&id=Sv2jkfTJCzLQ&format=png&color=228BE6',
  },
  { name: 'Math Tools', icon: 'https://img.icons8.com/?size=100&id=9470&format=png&color=228BE6' },
  {
    name: 'Science Equipment',
    icon: 'https://img.icons8.com/?size=100&id=2l4z0Vf4ihEA&format=png&color=228BE6',
  },
  {
    name: 'Digital Media',
    icon: 'https://img.icons8.com/?size=100&id=qlvJFYr0yTGO&format=png&color=228BE6',
  },
  {
    name: 'Writing & Stationary Supplies',
    icon: 'https://img.icons8.com/?size=100&id=ZTEqGMz6ATHM&format=png&color=228BE6',
  },
  {
    name: 'Monetary Donations',
    icon: 'https://img.icons8.com/?size=100&id=7977&format=png&color=228BE6',
  },
  { name: 'Services', icon: 'https://img.icons8.com/?size=100&id=42235&format=png&color=228BE6' },
  {
    name: 'Others',
    icon: 'https://img.icons8.com/?size=100&id=ZsYJzYlThVLD&format=png&color=228BE6',
  },
]

const selectedCategory = ref('')
const isSubmitting = ref(false)
const showImageUpload = ref(true) // Controls which image input method is shown

// Form data model
const formData = ref({
  resource_type: '',
  title: '',
  quantity: 1,
  condition: '',
  description: '',
  deliveryMethod: '',
  isRecurring: false,
  specialInstructions: '',
  image_link: '',
  image_file: null, // Added for file upload
})

// Computed property to show/hide donation form
const showDonationForm = computed(() => {
  return (
    selectedCategory.value &&
    selectedCategory.value !== 'Monetary Donations' &&
    selectedCategory.value !== 'Services'
  )
})

// Handle category selection
const handleCategoryClick = (categoryName) => {
  selectedCategory.value = categoryName
  formData.value.resource_type = categoryName

  if (categoryName === 'Monetary Donations') {
    router.push('/moneyDonations')
  } else if (categoryName === 'Services') {
    router.push('/serviceDonation')
  }
}

// Handle image upload
const handleImageUpload = async (event) => {
  const file = event.target.files[0]
  if (!file) return

  formData.value.image_file = file
  formData.value.image_link = URL.createObjectURL(file)
}

// Handle form submission
// In your donation.vue component
const handleSubmit = async () => {
  isSubmitting.value = true

  try {
    console.log('Submitting donation:', formData.value) // Debug log

    const response = await fetch('http://localhost:5038/api/donations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
      body: JSON.stringify(formData.value),
    })

    const data = await response.json()

    if (!response.ok) {
      console.error('Server responded with error:', data)
      throw new Error(data.error || `Server returned ${response.status}`)
    }

    console.log('Donation submitted successfully:', data)
    router.push({
      name: 'thankDonation',
      params: { donationId: data.donation.donation_id },
    })
  } catch (error) {
    console.error('Submission error:', error)

    let errorMessage = 'There was an error submitting your donation.'
    if (error.message.includes('401')) {
      errorMessage = 'Please log in to submit a donation.'
    } else if (error.message.includes('Failed to create')) {
      errorMessage = 'Server error. Please try again later.'
    }

    alert(errorMessage)
  } finally {
    isSubmitting.value = false
  }
}

// Reset form
const resetForm = () => {
  selectedCategory.value = ''
  formData.value = {
    resource_type: '',
    title: '',
    quantity: 1,
    condition: '',
    description: '',
    deliveryMethod: '',
    isRecurring: false,
    specialInstructions: '',
    image_link: '',
    image_file: null,
  }
  showImageUpload.value = true
}
</script>

<style scoped>
/* Global Styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Inter', sans-serif;
}

body {
  background-color: #f8f9fa;
  color: #333;
}

.container {
  width: 90%;
  max-width: 1200px;
  margin: 0 auto;
}

/* Navigation Bar */
nav {
  background-color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 1rem 0;
  position: sticky;
  top: 0;
  z-index: 100;
}

.nav-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo {
  display: flex;
  align-items: center;
  gap: 10px;
}

.logo img {
  height: 40px;
}

.logo-text {
  font-size: 1.5rem;
  font-weight: 700;
  color: #2462eb;
}

.nav-links {
  display: flex;
  gap: 2rem;
}

.nav-links a {
  text-decoration: none;
  color: #333;
  font-weight: 500;
  transition: color 0.3s;
}

.nav-links a:hover {
  color: #2462eb;
}

/* Hero Section */
.hero {
  text-align: center;
  padding: 4rem 0;
  background-color: #f0f4f8;
}

.hero h1 {
  font-size: 2.5rem;
  margin-bottom: 1rem;
  color: #111826;
}

.hero p {
  font-size: 1.2rem;
  color: #4b5462;
  max-width: 600px;
  margin: 0 auto;
}

/* Categories Section */
.categories {
  padding: 3rem 0;
}

.categories-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2rem;
  margin-top: 2rem;
}

.category-card {
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  text-align: center;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
  transition:
    transform 0.3s,
    box-shadow 0.3s;
  cursor: pointer;
}

.category-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
}

.category-card.selected {
  border: 2px solid #2462eb;
  background-color: #f0f7ff;
}

.category-icon {
  width: 60px;
  height: 60px;
  margin: 0 auto 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #e6f0ff;
  border-radius: 50%;
}

.category-icon img {
  width: 30px;
  height: 30px;
}

.category-name {
  font-weight: 600;
  color: #111826;
}

/* Donation Form */
.donation-form {
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  margin: 2rem 0;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
}

.form-section {
  margin-bottom: 2rem;
}

.form-section h2 {
  font-size: 1.5rem;
  margin-bottom: 1.5rem;
  color: #111826;
  border-bottom: 2px solid #f0f4f8;
  padding-bottom: 0.5rem;
}

.form-row {
  display: flex;
  gap: 1rem;
  margin-bottom: 1rem;
}

.form-group {
  flex: 1;
}

label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
  color: #4b5462;
}

input,
textarea,
select {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
}

textarea {
  min-height: 100px;
  resize: vertical;
}

.image-upload {
  border: 2px dashed #ddd;
  border-radius: 4px;
  padding: 2rem;
  text-align: center;
  cursor: pointer;
}

.image-upload:hover {
  border-color: #2462eb;
}

/* Delivery Options */
.delivery-options {
  display: flex;
  gap: 1rem;
}

.delivery-option {
  flex: 1;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 1.5rem;
  cursor: pointer;
  transition: all 0.3s;
}

.delivery-option:hover {
  border-color: #2462eb;
}

.delivery-option.selected {
  border-color: #2462eb;
  background-color: #f0f7ff;
}

.radio-container {
  display: flex;
  align-items: center;
  margin-bottom: 0.5rem;
}

.radio-container input {
  width: auto;
  margin-right: 0.5rem;
}

.option-description {
  color: #4b5462;
  font-size: 0.9rem;
}

/* Additional Options */
.toggle-group {
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
}

.toggle-switch {
  position: relative;
  display: inline-block;
  width: 50px;
  height: 24px;
  margin-right: 1rem;
}

.toggle-switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  transition: 0.4s;
  border-radius: 24px;
}

.slider:before {
  position: absolute;
  content: '';
  height: 16px;
  width: 16px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  transition: 0.4s;
  border-radius: 50%;
}

input:checked + .slider {
  background-color: #2462eb;
}

input:checked + .slider:before {
  transform: translateX(26px);
}

/* Form Buttons */
.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  margin-top: 2rem;
}

.btn {
  padding: 0.75rem 1.5rem;
  border-radius: 4px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
  border: none;
  font-size: 1rem;
}

.btn-primary {
  background-color: #2462eb;
  color: white;
}

.btn-primary:hover {
  background-color: #1a4fc8;
}

.btn-secondary {
  background-color: #f0f4f8;
  color: #4b5462;
}

.btn-secondary:hover {
  background-color: #e0e6ed;
}
.logo-text::before {
  content: '🎓';
  margin-right: 5px;
}
.image-input-toggle {
  display: flex;
  margin-bottom: 1rem;
  border-radius: 4px;
  overflow: hidden;
}

.image-input-toggle button {
  flex: 1;
  padding: 0.5rem;
  border: 1px solid #ddd;
  background-color: #f8f9fa;
  cursor: pointer;
  transition: all 0.3s;
}

.image-input-toggle button.active {
  background-color: #2462eb;
  color: white;
  border-color: #2462eb;
}

.image-input-toggle button:first-child {
  border-right: none;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}

.image-input-toggle button:last-child {
  border-left: none;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

.btn-remove-image {
  display: block;
  margin-top: 0.5rem;
  padding: 0.25rem 0.5rem;
  background-color: #f8f9fa;
  border: 1px solid #ddd;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-remove-image:hover {
  background-color: #e0e6ed;
}
/* New styles for image input options */
.image-input-options {
  display: flex;
  margin-bottom: 1rem;
  border-radius: 4px;
  overflow: hidden;
}

.image-input-options button {
  flex: 1;
  padding: 0.5rem;
  border: 1px solid #ddd;
  background-color: #f8f9fa;
  cursor: pointer;
  transition: all 0.3s;
}

.image-input-options button.active {
  background-color: #2462eb;
  color: white;
  border-color: #2462eb;
}

.image-input-options button:first-child {
  border-right: none;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}

.image-input-options button:last-child {
  border-left: none;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

/* Rest of your existing styles */
</style>
