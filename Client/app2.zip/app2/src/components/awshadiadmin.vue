<template>
    <div class="admin-container">
      <!-- Slide Bar (Navigation Header) -->
      <div class="slide-bar">
        <div class="logo">EduShare Admin</div>
  
        <nav class="nav-menu">
          <router-link to="/dashboard" class="nav-item">
            <span class="nav-icon">📊</span>
            <span class="nav-text">Dashboard</span>
          </router-link>
          <router-link to="/resource-review" class="nav-item active">
            <span class="nav-icon">📚</span>
            <span class="nav-text">Resource Review</span>
          </router-link>
          <router-link to="/user-management" class="nav-item">
            <span class="nav-icon">👥</span>
            <span class="nav-text">User Management</span>
          </router-link>
          <router-link to="/messages" class="nav-item">
            <span class="nav-icon">💬</span>
            <span class="nav-text">Messages</span>
          </router-link>
        </nav>
  
        <div class="user-controls">
          <button class="notification-btn">
            <span class="icon">🔔</span>
            <span class="badge">3</span>
          </button>
          <div class="user-profile">
            <img src="https://via.placeholder.com/36" alt="Admin" class="avatar" />
            <span class="username">Admin User</span>
          </div>
        </div>
      </div>
  
      <!-- Main Content -->
      <div class="resource-review-container">
        <!-- Sidebar -->
        <div class="sidebar">
          <h2 class="sidebar-title">Review Resources</h2>
          <div class="resource-list">
            <div
              v-for="item in resources"
              :key="item.id"
              @click="selectResource(item)"
              :class="['resource-item', selectedResource.id === item.id ? 'selected' : '']"
            >
              <div class="item-header">
                <img :src="item.thumbnail" alt="thumbnail" class="item-thumbnail" />
                <div class="item-details">
                  <h3 class="item-title">{{ item.title }}</h3>
                  <p class="item-donor">Donated by {{ item.donor }}</p>
                  <span class="item-condition">{{ item.condition }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
  
        <!-- Main Content Area -->
        <div class="main-content">
          <!-- Image Gallery -->
          <div class="image-gallery">
            <img
              v-for="(img, index) in selectedResource.images"
              :key="index"
              :src="img"
              class="gallery-image"
            />
          </div>
  
          <!-- Resource Details -->
          <div class="resource-details">
            <h2 class="resource-title">{{ selectedResource.title }}</h2>
            <p class="resource-description">{{ selectedResource.description }}</p>
          </div>
  
          <!-- Quality Checklist -->
          <div class="quality-checklist">
            <h3 class="checklist-title">Quality Standards</h3>
            <div v-for="(item, index) in checklistItems" :key="index" class="checkbox-item">
              <input type="checkbox" :id="'check-' + index" v-model="checklist" :value="item" />
              <label :for="'check-' + index">{{ item }}</label>
            </div>
          </div>
  
          <!-- Action Buttons -->
          <div class="action-buttons">
            <button class="btn approve-btn" @click="approveResource">
              <span class="btn-icon">✓</span> Approve
            </button>
            <button class="btn remove-btn" @click="removeResource">
              <span class="btn-icon">✗</span> Remove
            </button>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  defineOptions({ name: 'ResourceReview' })
  import { ref } from 'vue'
  
  const resources = ref([
    {
      id: 1,
      title: 'Math Textbooks - 20 units',
      donor: 'John Smith',
      condition: 'Used - Fair',
      description:
        'Complete set of mathematics textbooks for grades 9-12, covering algebra, geometry, and calculus. Books are in fair condition with some wear but all content is intact and usable.',
      thumbnail: 'https://via.placeholder.com/60x60?text=Math',
      images: [
        'https://via.placeholder.com/300x150?text=Math+Books',
        'https://via.placeholder.com/300x150?text=Lab',
        'https://via.placeholder.com/300x150?text=Art',
        'https://via.placeholder.com/300x150?text=Textbook+Open',
      ],
    },
    {
      id: 2,
      title: 'Science Lab Equipment Set',
      donor: 'Sarah Johnson',
      condition: 'New',
      description: 'Brand new lab equipment set including microscopes, beakers, and chemicals.',
      thumbnail: 'https://via.placeholder.com/60x60?text=Lab',
      images: [
        'https://via.placeholder.com/300x150?text=Microscope',
        'https://via.placeholder.com/300x150?text=Beakers',
        'https://via.placeholder.com/300x150?text=Test+Tubes',
        'https://via.placeholder.com/300x150?text=Chemicals',
      ],
    },
    {
      id: 3,
      title: 'Art Supplies Bundle',
      donor: 'Creative Studios',
      condition: 'Used - Good',
      description: 'Various art supplies including colored pencils, sketch pads, and paint.',
      thumbnail: 'https://via.placeholder.com/60x60?text=Art',
      images: [
        'https://via.placeholder.com/300x150?text=Colored+Pencils',
        'https://via.placeholder.com/300x150?text=Paint+Brushes',
        'https://via.placeholder.com/300x150?text=Sketch+Pads',
        'https://via.placeholder.com/300x150?text=Acrylics',
      ],
    },
  ])
  
  const selectedResource = ref(resources.value[0])
  const checklist = ref([])
  
  const checklistItems = [
    'Meets Quality Guidelines',
    'Age-Appropriate',
    'Functional',
    'Complete Set',
    'No Missing Pages',
  ]
  
  const selectResource = (item) => {
    selectedResource.value = item
    checklist.value = []
  }
  
  const approveResource = () => {
    alert(`Approved: ${selectedResource.value.title}`)
  }
  
  const removeResource = () => {
    alert(`Approved: ${selectedResource.value.title}`)
  }
  </script>
  
  <style scoped>
  /* Slide Bar Styles */
  .slide-bar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 60px;
    background-color: #fff;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    z-index: 1000;
  }
  
  .logo {
    font-size: 1.2rem;
    font-weight: 600;
    color: #4361ee;
  }
  
  .nav-menu {
    display: flex;
    gap: 15px;
  }
  
  .nav-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 15px;
    border-radius: 6px;
    text-decoration: none;
    color: #555;
    transition: all 0.3s ease;
  }
  
  .nav-item:hover {
    background-color: rgba(67, 97, 238, 0.1);
  }
  
  .nav-item.active {
    background-color: rgba(67, 97, 238, 0.1);
    color: #4361ee;
    font-weight: 500;
  }
  
  .nav-icon {
    font-size: 1.1rem;
  }
  
  .user-controls {
    display: flex;
    align-items: center;
    gap: 15px;
  }
  
  .notification-btn {
    position: relative;
    background: none;
    border: none;
    cursor: pointer;
    font-size: 1.2rem;
  }
  
  .badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background-color: #f94144;
    color: white;
    border-radius: 50%;
    width: 18px;
    height: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.7rem;
    font-weight: 600;
  }
  
  .user-profile {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  
  .avatar {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    object-fit: cover;
  }
  
  .username {
    font-weight: 500;
    font-size: 0.9rem;
  }
  
  /* Main Container */
  .admin-container {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
  }
  
  .resource-review-container {
    display: flex;
    flex: 1;
    margin-top: 60px; /* To account for the fixed header */
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f8f9fa;
  }
  
  /* Sidebar Styles */
  .sidebar {
    width: 350px;
    background: #ffffff;
    padding: 24px;
    border-right: 1px solid #e0e0e0;
    overflow-y: auto;
  }
  
  .sidebar-title {
    font-size: 1.5rem;
    font-weight: 600;
    color: #2c3e50;
    margin-bottom: 24px;
    padding-bottom: 16px;
    border-bottom: 1px solid #eee;
  }
  
  .resource-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  
  .resource-item {
    padding: 16px;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
  }
  
  .resource-item:hover {
    background-color: #f5f5f5;
    border-color: #d0d0d0;
  }
  
  .resource-item.selected {
    border-color: #4361ee;
    background-color: #f0f4ff;
    box-shadow: 0 2px 8px rgba(67, 97, 238, 0.1);
  }
  
  .item-header {
    display: flex;
    align-items: flex-start;
    gap: 16px;
  }
  
  .item-thumbnail {
    width: 60px;
    height: 60px;
    object-fit: cover;
    border-radius: 6px;
    flex-shrink: 0;
  }
  
  .item-details {
    flex: 1;
  }
  
  .item-title {
    font-size: 1rem;
    font-weight: 500;
    color: #2c3e50;
    margin-bottom: 4px;
  }
  
  .item-donor {
    font-size: 0.875rem;
    color: #666;
    margin-bottom: 6px;
  }
  
  .item-condition {
    display: inline-block;
    padding: 2px 8px;
    font-size: 0.75rem;
    background-color: #f0f0f0;
    border-radius: 4px;
    color: #555;
  }
  
  /* Main Content Styles */
  .main-content {
    flex: 1;
    padding: 32px;
    display: flex;
    flex-direction: column;
    gap: 24px;
    background-color: #fff;
  }
  
  .image-gallery {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
    margin-bottom: 16px;
  }
  
  .gallery-image {
    width: 100%;
    height: 180px;
    object-fit: cover;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s;
  }
  
  .gallery-image:hover {
    transform: scale(1.02);
  }
  
  .resource-details {
    margin-bottom: 16px;
  }
  
  .resource-title {
    font-size: 1.5rem;
    font-weight: 600;
    color: #2c3e50;
    margin-bottom: 12px;
  }
  
  .resource-description {
    font-size: 1rem;
    line-height: 1.6;
    color: #555;
  }
  
  /* Quality Checklist */
  .quality-checklist {
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 8px;
    margin-top: 16px;
  }
  
  .checklist-title {
    font-size: 1.2rem;
    font-weight: 500;
    color: #2c3e50;
    margin-bottom: 16px;
  }
  
  .checkbox-item {
    display: flex;
    align-items: center;
    margin-bottom: 12px;
  }
  
  .checkbox-item input[type='checkbox'] {
    width: 18px;
    height: 18px;
    margin-right: 12px;
    accent-color: #4361ee;
  }
  
  .checkbox-item label {
    font-size: 1rem;
    color: #444;
    cursor: pointer;
  }
  
  /* Action Buttons */
  .action-buttons {
    display: flex;
    gap: 16px;
    margin-top: 24px;
  }
  
  .btn {
    padding: 12px 24px;
    border: none;
    border-radius: 6px;
    font-size: 1rem;
    font-weight: 500;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s ease;
  }
  
  .btn-icon {
    font-size: 1.1rem;
  }
  
  .approve-btn {
    background-color: #28a745;
    color: white;
  }
  
  .approve-btn:hover {
    background-color: #218838;
  }
  
  .remove-btn {
    background-color: #dc3545;
    color: white;
  }
  
  .remove-btn:hover {
    background-color: #c82333;
  }
  
  /* Responsive Design */
  @media (max-width: 992px) {
    .resource-review-container {
      flex-direction: column;
    }
  
    .sidebar {
      width: 100%;
      border-right: none;
      border-bottom: 1px solid #e0e0e0;
    }
  
    .image-gallery {
      grid-template-columns: 1fr;
    }
  
    .nav-menu {
      display: none; /* Hide nav menu on smaller screens */
    }
  }
  
  @media (max-width: 576px) {
    .main-content {
      padding: 20px;
    }
  
    .action-buttons {
      flex-direction: column;
    }
  
    .btn {
      width: 100%;
      justify-content: center;
    }
  
    .slide-bar {
      padding: 0 10px;
      height: 50px;
      justify-content: space-between;
    }
  
    .logo {
      font-size: 1rem;
    }
  
    .user-profile .username {
      display: none;
    }
  }
  </style>