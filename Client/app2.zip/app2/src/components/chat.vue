<template>
  <div class="chat-container">
    <!-- Header -->
    <div class="chat-header">
      <h2>EduShare Chat</h2>
      <div class="connection-status" :class="{ connected: isConnected }">
        {{ isConnected ? 'Connected' : 'Disconnected' }}
      </div>
    </div>

    <!-- Messages -->
    <div class="messages" ref="messagesContainer">
      <div v-for="(message, index) in messages" :key="index" class="message" 
           :class="{ 'outgoing': message.sender === currentUser.id, 'incoming': message.sender !== currentUser.id }">
        <div v-if="message.sender !== currentUser.id" class="sender-info">
          <span class="sender-name">{{ getSenderName(message.sender) }}</span>
          <span class="message-time">{{ formatTime(message.timestamp) }}</span>
        </div>
        <div class="message-content">
          {{ message.content }}
        </div>
        <div v-if="message.sender === currentUser.id" class="message-time">
          {{ formatTime(message.timestamp) }}
        </div>
      </div>
    </div>

    <!-- Message Input -->
    <div class="message-input">
      <input
        v-model="newMessage"
        @keyup.enter="sendMessage"
        placeholder="Type your message..."
        :disabled="!isConnected"
      />
      <button @click="sendMessage" :disabled="!isConnected || !newMessage.trim()">
        Send
      </button>
    </div>

    <!-- User Selection (for demo purposes) -->
    <div class="user-selection">
      <label>You are:</label>
      <select v-model="currentUser.id" @change="updateConnection">
        <option value="user1">Donor (User 1)</option>
        <option value="user2">Recipient (User 2)</option>
      </select>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, watch, nextTick } from 'vue';

// Demo user data (in a real app, this would come from authentication)
const users = {
  user1: { id: 'user1', name: 'Donor User' },
  user2: { id: 'user2', name: 'Recipient Org' }
};

// Component state
const currentUser = ref(users.user1);
const newMessage = ref('');
const messages = ref([]);
const isConnected = ref(false);
const messagesContainer = ref(null);
const socket = ref(null);

// WebSocket connection
const connectWebSocket = () => {
  // In production, use your actual WebSocket server URL
  const wsUrl = 'ws://localhost:3000' || `wss://${window.location.host}`;
  
  socket.value = new WebSocket(wsUrl);

  socket.value.onopen = () => {
    isConnected.value = true;
    console.log('WebSocket connected');
    sendSystemMessage('You are now connected to the chat');
  };

  socket.value.onmessage = (event) => {
    const message = JSON.parse(event.data);
    messages.value.push(message);
    scrollToBottom();
  };

  socket.value.onclose = () => {
    isConnected.value = false;
    console.log('WebSocket disconnected');
    sendSystemMessage('You have been disconnected from the chat');
  };

  socket.value.onerror = (error) => {
    console.error('WebSocket error:', error);
    sendSystemMessage('Connection error occurred');
  };
};

const updateConnection = () => {
  if (socket.value) {
    socket.value.close();
  }
  messages.value = [];
  connectWebSocket();
};

const sendMessage = () => {
  if (!newMessage.value.trim() || !isConnected.value) return;

  const message = {
    sender: currentUser.value.id,
    content: newMessage.value.trim(),
    timestamp: new Date().getTime()
  };

  // In a real app, this would go to the WebSocket server
  if (socket.value && socket.value.readyState === WebSocket.OPEN) {
    socket.value.send(JSON.stringify(message));
  } else {
    // Fallback for demo purposes
    messages.value.push(message);
    scrollToBottom();
  }

  newMessage.value = '';
};

const sendSystemMessage = (text) => {
  messages.value.push({
    sender: 'system',
    content: text,
    timestamp: new Date().getTime()
  });
  scrollToBottom();
};

const scrollToBottom = () => {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight;
    }
  });
};

const getSenderName = (senderId) => {
  return users[senderId]?.name || senderId;
};

const formatTime = (timestamp) => {
  return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
};

// Lifecycle hooks
onMounted(() => {
  connectWebSocket();
  // Demo messages
  setTimeout(() => {
    messages.value.push({
      sender: 'user2',
      content: 'Hello! Thank you for your donation offer.',
      timestamp: new Date().getTime() - 60000
    });
    scrollToBottom();
  }, 1000);
});

onBeforeUnmount(() => {
  if (socket.value) {
    socket.value.close();
  }
});
</script>

<style scoped>
.chat-container {
  display: flex;
  flex-direction: column;
  height: 500px;
  max-width: 600px;
  margin: 0 auto;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  background-color: white;
}

.chat-header {
  padding: 16px;
  background-color: #3b82f6;
  color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.chat-header h2 {
  margin: 0;
  font-size: 1.25rem;
}

.connection-status {
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 0.75rem;
  background-color: #ef4444;
  color: white;
}

.connection-status.connected {
  background-color: #10b981;
}

.messages {
  flex: 1;
  padding: 16px;
  overflow-y: auto;
  background-color: #f8fafc;
}

.message {
  margin-bottom: 12px;
  max-width: 80%;
}

.message-content {
  padding: 8px 12px;
  border-radius: 12px;
  word-wrap: break-word;
}

.incoming .message-content {
  background-color: white;
  border: 1px solid #e2e8f0;
  border-bottom-left-radius: 4px;
}

.outgoing .message-content {
  background-color: #3b82f6;
  color: white;
  border-bottom-right-radius: 4px;
  margin-left: auto;
}

.sender-info {
  display: flex;
  align-items: center;
  margin-bottom: 4px;
  font-size: 0.75rem;
}

.sender-name {
  font-weight: 600;
  margin-right: 8px;
  color: #1e293b;
}

.message-time {
  font-size: 0.7rem;
  color: #64748b;
  margin-top: 4px;
}

.outgoing .message-time {
  text-align: right;
}

.message-input {
  display: flex;
  padding: 12px;
  border-top: 1px solid #e2e8f0;
  background-color: white;
}

.message-input input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  margin-right: 8px;
}

.message-input button {
  padding: 8px 16px;
  background-color: #3b82f6;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
}

.message-input button:disabled {
  background-color: #cbd5e1;
  cursor: not-allowed;
}

.user-selection {
  padding: 8px 12px;
  background-color: #f1f5f9;
  border-top: 1px solid #e2e8f0;
  font-size: 0.875rem;
}

.user-selection select {
  margin-left: 8px;
  padding: 4px;
  border-radius: 4px;
  border: 1px solid #cbd5e1;
}

/* Animation for new messages */
.message {
  animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>