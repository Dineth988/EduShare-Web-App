<template>
  <div class="login-page">
    <div class="login-container">
      <!-- Logo Header -->
      <div class="logo-header">
        <span class="logo-icon">🎓</span>
        <h1>EduShare</h1>
        <p class="tagline">Connecting donors with educational needs</p>
      </div>

      <!-- Login Form -->
      <form @submit.prevent="handleLogin" class="login-form">
        <div class="form-group">
          <label for="email">Email Address</label>
          <input
            v-model="form.email"
            type="email"
            id="email"
            placeholder="Enter your email"
            required
            :class="{ 'input-error': errors.email }"
          />
          <span class="error-message" v-if="errors.email">{{ errors.email }}</span>
        </div>

        <div class="form-group">
          <label for="password">Password</label>
          <div class="password-input">
            <input
              v-model="form.password"
              :type="showPassword ? 'text' : 'password'"
              id="password"
              placeholder="Enter your password"
              required
              :class="{ 'input-error': errors.password }"
            />
            <button
              type="button"
              class="toggle-password"
              @click="showPassword = !showPassword"
              aria-label="Toggle password visibility"
            >
              <span v-if="showPassword">👁️</span>
              <span v-else>👁️‍🗨️</span>
            </button>
          </div>
          <span class="error-message" v-if="errors.password">{{ errors.password }}</span>
        </div>

        <div class="form-options">
          <label class="remember-me">
            <input type="checkbox" v-model="form.rememberMe" />
            <span>Remember me</span>
          </label>
          <router-link to="/forgot-password" class="forgot-password">Forgot password?</router-link>
        </div>

        <button type="submit" class="login-button" :disabled="loading">
          <span v-if="!loading">Log In</span>
          <span v-else class="loading-spinner"></span>
        </button>

        <div class="social-login">
          <p class="divider">or continue with</p>
          <div class="social-buttons">
            <button type="button" class="social-button google" @click="loginWithGoogle">
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg"
                alt="Google"
              />
            </button>
            <button type="button" class="social-button facebook" @click="loginWithFacebook">
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg"
                alt="Facebook"
              />
            </button>
          </div>
        </div>

        <p class="signup-link">
          Don't have an account? <router-link to="/signup">Sign up</router-link>
        </p>
      </form>
    </div>

    <!-- Decorative Elements -->
    <div class="decorative-shapes">
      <div class="shape circle"></div>
      <div class="shape triangle"></div>
      <div class="shape square"></div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'LoginPage',
  data() {
    return {
      form: {
        email: '',
        password: '',
        rememberMe: false,
      },
      errors: {
        email: '',
        password: '',
        form: '',
      },
      showPassword: false,
      loading: false,
    }
  },
  methods: {
    validateForm() {
      let isValid = true
      this.errors = { email: '', password: '', form: '' }

      // Email validation
      if (!this.form.email) {
        this.errors.email = 'Email is required'
        isValid = false
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.form.email)) {
        this.errors.email = 'Please enter a valid email address'
        isValid = false
      }

      // Password validation
      if (!this.form.password) {
        this.errors.password = 'Password is required'
        isValid = false
      } else if (this.form.password.length < 6) {
        this.errors.password = 'Password must be at least 6 characters'
        isValid = false
      }

      return isValid
    },
    async handleLogin() {
      if (!this.validateForm()) return

      this.loading = true
      this.errors.form = ''

      try {
        const response = await fetch('http://localhost:5038/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email: this.form.email,
            password: this.form.password,
          }),
          credentials: 'include',
        })

        // First check if response is JSON
        const contentType = response.headers.get('content-type')
        if (!contentType || !contentType.includes('application/json')) {
          const text = await response.text()
          throw new Error(text || 'Invalid server response')
        }

        const data = await response.json()

        if (!response.ok) {
          throw new Error(data.message || 'Login failed')
        }

        // Store user data in multiple places
        localStorage.setItem('userId', data.user.userId)
        localStorage.setItem('userEmail', data.user.email)

        // If using global variable
        if (this.$currentUser) {
          this.$currentUser.id = data.user.userId
          this.$currentUser.email = data.user.email
          this.$currentUser.role = data.user.role
        }

        console.log('Logged in user ID:', data.user.userId)

        // Redirect to profile or intended page
        const redirectPath = this.$route.query.redirect || '/profile'
        this.$router.push(redirectPath)
      } catch (error) {
        console.error('Login error:', error)
        this.errors.form = error.message || 'Login failed. Please try again.'

        // Clear any partial authentication on error
        localStorage.removeItem('userId')
        localStorage.removeItem('userEmail')
        if (this.$currentUser) {
          this.$currentUser.id = null
          this.$currentUser.email = null
          this.$currentUser.role = null
        }
      } finally {
        this.loading = false
      }
    },
    loginWithGoogle() {
      // Consider adding state parameter for security
      window.location.href = 'http://localhost:5038/api/auth/google'
    },
    loginWithFacebook() {
      window.location.href = 'http://localhost:5038/api/auth/facebook'
    },
  },
}
</script>

<style scoped>
/* Base Styles */
.login-page {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #f8f9fa;
  position: relative;
  overflow: hidden;
  padding: 20px;
}

.login-container {
  background-color: white;
  border-radius: 16px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
  padding: 40px;
  width: 100%;
  max-width: 420px;
  z-index: 1;
  position: relative;
}

/* Logo Header */
.logo-header {
  text-align: center;
  margin-bottom: 32px;
}

.logo-icon {
  font-size: 48px;
  display: inline-block;
  margin-bottom: 12px;
}

.logo-header h1 {
  font-size: 28px;
  font-weight: 700;
  color: #212529;
  margin: 0;
}

.tagline {
  color: #6c757d;
  font-size: 14px;
  margin-top: 8px;
}

/* Form Styles */
.login-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

label {
  font-size: 14px;
  font-weight: 500;
  color: #495057;
}

input {
  padding: 12px 16px;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  font-size: 14px;
  transition: all 0.2s;
}

input:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.1);
}

.input-error {
  border-color: #dc3545;
}

.input-error:focus {
  box-shadow: 0 0 0 3px rgba(220, 53, 69, 0.1);
}

.error-message {
  color: #dc3545;
  font-size: 12px;
  margin-top: 4px;
}

/* Password Input */
.password-input {
  position: relative;
}

.toggle-password {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
  font-size: 16px;
  color: #6c757d;
}

/* Form Options */
.form-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 14px;
}

.remember-me {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #495057;
  cursor: pointer;
}

.remember-me input {
  margin: 0;
}

.forgot-password {
  color: #007bff;
  text-decoration: none;
  transition: color 0.2s;
}

.forgot-password:hover {
  color: #0056b3;
  text-decoration: underline;
}

/* Login Button */
.login-button {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 14px;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 8px;
}

.login-button:hover {
  background-color: #0069d9;
}

.login-button:disabled {
  background-color: #6c757d;
  cursor: not-allowed;
}

.loading-spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: white;
  animation: spin 1s ease-in-out infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

/* Social Login */
.social-login {
  margin-top: 24px;
}

.divider {
  display: flex;
  align-items: center;
  color: #6c757d;
  font-size: 14px;
  margin: 20px 0;
}

.divider::before,
.divider::after {
  content: '';
  flex: 1;
  border-bottom: 1px solid #dee2e6;
}

.divider::before {
  margin-right: 16px;
}

.divider::after {
  margin-left: 16px;
}

.social-buttons {
  display: flex;
  justify-content: center;
  gap: 16px;
}

.social-button {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  border: 1px solid #dee2e6;
  background-color: white;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  transition: all 0.2s;
}

.social-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.social-button img {
  width: 20px;
  height: 20px;
}

.google:hover {
  background-color: #f8f9fa;
}

.facebook {
  background-color: #1877f2;
  border-color: #1877f2;
}

.facebook:hover {
  background-color: #166fe5;
}

/* Sign Up Link */
.signup-link {
  text-align: center;
  color: #6c757d;
  font-size: 14px;
  margin-top: 24px;
}

.signup-link a {
  color: #007bff;
  text-decoration: none;
  font-weight: 500;
}

.signup-link a:hover {
  text-decoration: underline;
}

/* Decorative Elements */
.decorative-shapes {
  position: absolute;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 0;
}

.shape {
  position: absolute;
  opacity: 0.1;
}

.circle {
  width: 300px;
  height: 300px;
  border-radius: 50%;
  background-color: #007bff;
  top: -150px;
  right: -150px;
}

.triangle {
  width: 0;
  height: 0;
  border-left: 150px solid transparent;
  border-right: 150px solid transparent;
  border-bottom: 260px solid #28a745;
  bottom: -130px;
  left: -75px;
  transform: rotate(15deg);
}

.square {
  width: 200px;
  height: 200px;
  background-color: #ffc107;
  bottom: 50px;
  right: 50px;
  transform: rotate(45deg);
}

/* Responsive Design */
@media (max-width: 480px) {
  .login-container {
    padding: 30px 20px;
  }

  .logo-icon {
    font-size: 40px;
  }

  .logo-header h1 {
    font-size: 24px;
  }

  .decorative-shapes {
    display: none;
  }
}
</style>
