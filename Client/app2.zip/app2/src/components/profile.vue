<template>
  <div class="profile-page">
    <!-- Navigation Bar -->
    <div class="navbar">
      <div class="navbar-logo">EduShare</div>
      <div class="navbar-links">
        <router-link to="/home">Home</router-link>
        <router-link to="/browse">Browse</router-link>
        <router-link to="/messages">Messages</router-link>
        <router-link to="/notifications">Notifications</router-link>
      </div>
      <div class="navbar-actions">
        <button v-if="isAuthenticated" @click="handleLogout" class="logout-btn">Logout</button>
        <router-link v-else to="/login" class="login-link">Login</router-link>
      </div>
    </div>

    <!-- Loading State -->
    <div v-if="loading" class="loading-container">
      <div class="spinner"></div>
      <p>Loading your profile...</p>
    </div>

    <!-- Error State -->
    <div v-else-if="error" class="error-container">
      <p class="error-message">⚠️ {{ error }}</p>
      <button @click="fetchData" class="retry-btn">Try Again</button>
    </div>

    <!-- Unauthenticated State -->
    <div v-else-if="!isAuthenticated" class="auth-required">
      <p>Please <router-link to="/login">login</router-link> to view your profile</p>
    </div>

    <!-- Authenticated Content -->
    <template v-else>
      <!-- Profile Header -->
      <div class="header">
        <div class="profile-header-bg"></div>
      </div>

      <!-- Profile Info Section -->
      <div class="profile-info">
        <div class="profile-info-box">
          <div class="profile-image">
            <img :src="user.profile_pic || defaultProfilePic" alt="Profile Picture" />
          </div>
          <div class="profile-details">
            <h1>
              {{ user.full_name }}
              <span class="verified" v-if="user.organization_id">Verified NGO</span>
            </h1>
            <p>{{ user.bio || 'No bio available' }}</p>
            <router-link to="/edit-profile" class="edit-profile">Edit Profile</router-link>
          </div>
        </div>
      </div>

      <!-- Main Content -->
      <div class="container">
        <div class="left-column">
          <div class="card stats">
            <h2>Impact Statistics</h2>
            <div class="stat">
              <h3>{{ userStats.total_donations || '0' }}</h3>
              <p>Total Donations</p>
            </div>
            <div class="stat">
              <h3>{{ userStats.beneficiaries_reached || '1' }}+</h3>
              <p>Beneficiaries Reached</p>
            </div>
            <div class="stat">
              <h3>{{ userStats.categories_covered || '1' }}</h3>
              <p>Categories Covered</p>
            </div>
          </div>
        </div>

        <div class="right-column">
          <!-- Recent Donations -->
          <div class="card">
            <h2>Recent Donations</h2>
            <div v-if="donations.length === 0" class="empty-state">
              <p>No donations yet</p>
            </div>
            <div v-else>
              <div class="donation" v-for="donation in donations" :key="donation.donation_id">
                <img :src="donation.image_link || placeholderImage" :alt="donation.title" />
                <div class="donation-details">
                  <h3>{{ donation.title }}</h3>
                  <p>{{ donation.description || 'No description available' }}</p>
                  <p class="status">
                    {{ donation.status }} • {{ formatDate(donation.created_at) }}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <!-- Connected Organizations -->
          <div class="card">
            <h2>Connected Organizations</h2>
            <div v-if="organizations.length === 0" class="empty-state">
              <p>No connected organizations</p>
            </div>
            <div v-else class="organizations">
              <div class="org" v-for="org in organizations" :key="org.org_id">
                <img :src="org.logo || placeholderOrgImage" :alt="org.name" />
                <p>
                  {{ org.name }}<br /><span>{{ org.relationship }}</span>
                </p>
              </div>
            </div>
          </div>

          <!-- Quick Actions -->
          <div class="card quick-actions">
            <h2>Quick Actions</h2>
            <router-link to="/create-request" class="create">Create New Request</router-link>
            <button @click="shareProfile" class="share">Share Profile</button>
            <button @click="generateReport" class="report">Generate Report</button>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script>
export default {
  name: 'DonorProfile',
  data() {
    return {
      user: {},
      userStats: {},
      donations: [],
      organizations: [],
      loading: true,
      error: null,
      defaultProfilePic: 'https://img.icons8.com/?size=100&id=z-JBA_KtSkxG&format=png&color=000000',
      placeholderImage:
        'https://th.bing.com/th/id/OIP.EB_XenvrD5mgCpdq6-wyvQHaFO?cb=iwc2&rs=1&pid=ImgDetMain',
      placeholderOrgImage:
        'https://th.bing.com/th/id/OIP.EB_XenvrD5mgCpdq6-wyvQHaFO?cb=iwc2&rs=1&pid=ImgDetMain',
    }
  },
  computed: {
    isAuthenticated() {
      return !!localStorage.getItem('userId') || !!this.$currentUser?.id
    },
    userId() {
      return localStorage.getItem('userId') || this.$currentUser?.id || this.user.user_id
    },
  },
  methods: {
    formatDate(dateString) {
      if (!dateString) return ''
      const options = { year: 'numeric', month: 'short', day: 'numeric' }
      return new Date(dateString).toLocaleDateString(undefined, options)
    },

    async handleResponse(response) {
      const contentType = response.headers.get('content-type')
      if (!contentType || !contentType.includes('application/json')) {
        const text = await response.text()
        throw new Error(text || 'Invalid server response')
      }

      const data = await response.json()
      if (!response.ok) {
        throw new Error(data.message || 'Request failed')
      }
      return data
    },

    async fetchData() {
      this.loading = true
      this.error = null

      try {
        // First verify authentication
        const verifyResponse = await fetch('http://localhost:5038/api/auth/verify', {
          credentials: 'include',
        })

        const verifiedUser = await this.handleResponse(verifyResponse)
        const userId = verifiedUser.userId || this.userId

        if (!userId) throw new Error('No user ID available')

        // Fetch all data
        const [profile, stats, donations, orgs] = await Promise.all([
          fetch(`http://localhost:5038/api/users/${userId}`, {
            credentials: 'include',
          }).then(this.handleResponse),

          fetch(`http://localhost:5038/api/users/${userId}/stats`, {
            credentials: 'include',
          }).then(this.handleResponse),

          fetch(`http://localhost:5038/api/users/donations/${userId}`, {
            credentials: 'include',
          })
            .then(this.handleResponse)
            .then((donations) =>
              donations.map((d) => ({
                ...d,
                description: d.description || 'No description provided',
                image_link: d.image_link || this.placeholderImage,
              })),
            ),

          fetch(`http://localhost:5038/api/users/${userId}/organizations`, {
            credentials: 'include',
          })
            .then(this.handleResponse)
            .then((orgs) =>
              orgs.map((o) => ({
                ...o,
                logo: 'https://th.bing.com/th/id/OIP.EB_XenvrD5mgCpdq6-wyvQHaFO?cb=iwc2&rs=1&pid=ImgDetMain',
              })),
            ),
        ])

        this.user = profile
        this.userStats = stats
        this.donations = donations
        this.organizations = orgs
      } catch (error) {
        console.error('Failed to load profile data:', error)
        this.error = error.message.includes('Not authenticated')
          ? 'Please login to view your profile'
          : 'Failed to load profile data'

        if (error.message.includes('Not authenticated')) {
          localStorage.removeItem('userId')
          this.$router.push('/login')
        }
      } finally {
        this.loading = false
      }
    },

    async handleLogout() {
      try {
        await fetch('http://localhost:5038/api/auth/logout', {
          method: 'POST',
          credentials: 'include',
        })

        // Clear all user data
        localStorage.removeItem('userId')
        if (this.$currentUser) {
          this.$currentUser.id = null
          this.$currentUser.email = null
          this.$currentUser.role = null
        }
        this.user = {}

        this.$router.push('/login')
      } catch (error) {
        console.error('Logout error:', error)
        this.error = 'Failed to logout. Please try again.'
      }
    },

    shareProfile() {
      if (navigator.share) {
        navigator
          .share({
            title: `${this.user.full_name}'s Profile`,
            text: `Check out ${this.user.full_name}'s profile on EduShare`,
            url: window.location.href,
          })
          .catch((err) => console.log('Error sharing:', err))
      } else {
        // Fallback for browsers without Web Share API
        alert(`Share this URL: ${window.location.href}`)
      }
    },

    generateReport() {
      alert('Report generation would be implemented here')
    },
  },
  created() {
    // Initialize with stored user data if available
    const storedUserId = localStorage.getItem('userId')
    if (storedUserId) {
      this.user = { user_id: storedUserId }
    }
    this.fetchData()
  },
}
</script>

<style scoped>
/* Base Styles */
body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #f8f9fa;
  color: #333;
}

/* Navbar Styles */
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: white;
  padding: 15px 30px;
  border-bottom: 1px solid #e1e4e8;
  width: 100%;
  box-sizing: border-box;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.navbar-logo {
  display: flex;
  align-items: center;
  font-size: 24px;
  font-weight: 700;
  color: #007bff;
}

.navbar-logo::before {
  content: '🎓';
  margin-right: 8px;
}

.navbar-links {
  display: flex;
  gap: 25px;
}

.navbar-links a {
  text-decoration: none;
  color: #495057;
  font-size: 16px;
  font-weight: 500;
  transition: color 0.2s;
}

.navbar-links a:hover {
  color: #007bff;
}

.navbar-links a.router-link-exact-active {
  color: #007bff;
  border-bottom: 2px solid #007bff;
}

.navbar-actions {
  display: flex;
  gap: 15px;
  align-items: center;
}

.logout-btn,
.login-link {
  padding: 8px 16px;
  border-radius: 4px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.logout-btn {
  background-color: #f8f9fa;
  border: 1px solid #dc3545;
  color: #dc3545;
}

.logout-btn:hover {
  background-color: #dc3545;
  color: white;
}

.login-link {
  background-color: #007bff;
  color: white;
  text-decoration: none;
}

.login-link:hover {
  background-color: #0069d9;
}

/* Loading and Error States */
.loading-container,
.error-container,
.auth-required {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 300px;
  text-align: center;
}

.spinner {
  border: 4px solid rgba(0, 123, 255, 0.1);
  border-radius: 50%;
  border-top: 4px solid #007bff;
  width: 40px;
  height: 40px;
  animation: spin 1s linear infinite;
  margin-bottom: 20px;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.error-container {
  background-color: #fff3f3;
  border-radius: 8px;
  padding: 30px;
  margin: 20px;
}

.error-message {
  color: #dc3545;
  font-weight: 500;
  margin-bottom: 15px;
}

.retry-btn {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.retry-btn:hover {
  background-color: #0069d9;
}

.auth-required {
  font-size: 18px;
}

.auth-required a {
  color: #007bff;
  text-decoration: none;
  font-weight: 500;
}

/* Profile Header */
.header {
  height: 200px;
  position: relative;
  width: 100%;
}

.profile-header-bg {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-image: url('https://images.pexels.com/photos/1333742/pexels-photo-1333742.jpeg');
  background-size: cover;
  background-position: center;
  z-index: -1;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
}

/* Profile Info Section */
.profile-info {
  width: 100%;
  max-width: 1200px;
  margin: 20px auto;
  padding: 0 30px;
  box-sizing: border-box;
  position: relative;
  z-index: 1;
}

.profile-info-box {
  display: flex;
  align-items: center;
  background-color: white;
  border-radius: 10px;
  padding: 30px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  margin-top: -50px;
}

.profile-image img {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  border: 4px solid white;
  object-fit: cover;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.profile-details {
  margin-left: 30px;
  flex: 1;
}

.profile-details h1 {
  font-size: 28px;
  color: #212529;
  margin: 0 0 10px;
  display: flex;
  align-items: center;
  gap: 12px;
}

.verified {
  background-color: #e6ffe6;
  color: #28a745;
  padding: 4px 10px;
  border-radius: 10px;
  font-size: 14px;
  font-weight: 500;
}

.profile-details p {
  font-size: 16px;
  color: #6c757d;
  margin: 0 0 20px;
  line-height: 1.5;
  max-width: 600px;
}

.edit-profile {
  display: inline-block;
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
  text-decoration: none;
  font-size: 16px;
  font-weight: 500;
  transition: background-color 0.2s;
}

.edit-profile:hover {
  background-color: #0069d9;
}

/* Main Content Container */
.container {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px 30px;
  display: flex;
  gap: 20px;
  box-sizing: border-box;
}

.left-column {
  flex: 1;
  min-width: 300px;
}

.right-column {
  flex: 2;
  min-width: 400px;
}

/* Card Styles */
.card {
  background-color: white;
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
  transition:
    transform 0.2s,
    box-shadow 0.2s;
}

.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.card h2 {
  font-size: 18px;
  color: #212529;
  margin: 0 0 20px;
  padding-bottom: 10px;
  border-bottom: 1px solid #e1e4e8;
}

/* Stats Card */
.stats .stat {
  margin-bottom: 20px;
}

.stats .stat h3 {
  font-size: 24px;
  color: #007bff;
  margin: 0;
}

.stats .stat p {
  font-size: 14px;
  color: #6c757d;
  margin: 5px 0 0;
}

/* Donations List */
.donation {
  display: flex;
  gap: 20px;
  align-items: center;
  padding: 15px 0;
  border-bottom: 1px solid #f1f3f5;
}

.donation:last-child {
  border-bottom: none;
}

.donation img {
  width: 100px;
  height: 80px;
  object-fit: cover;
  border-radius: 5px;
}

.donation-details {
  flex: 1;
}

.donation-details h3 {
  font-size: 16px;
  color: #212529;
  margin: 0 0 5px;
}

.donation-details p {
  font-size: 14px;
  color: #6c757d;
  margin: 5px 0;
}

.donation-details .status {
  font-size: 12px;
  color: #6c757d;
}

.status.completed {
  color: #28a745;
}

.status.in-progress {
  color: #ffc107;
}

/* Organizations List */
.organizations .org {
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 10px 0;
}

.organizations .org img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
}

.organizations .org p {
  font-size: 14px;
  color: #212529;
  margin: 0;
}

.organizations .org p span {
  display: block;
  font-size: 12px;
  color: #6c757d;
}

/* Quick Actions */
.quick-actions a,
.quick-actions button {
  display: block;
  width: 100%;
  padding: 12px;
  border-radius: 5px;
  text-decoration: none;
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 10px;
  text-align: center;
  cursor: pointer;
  border: none;
  transition: all 0.2s;
}

.quick-actions .create {
  background-color: #007bff;
  color: white;
}

.quick-actions .create:hover {
  background-color: #0069d9;
}

.quick-actions .share,
.quick-actions .report {
  background-color: #f8f9fa;
  color: #495057;
}

.quick-actions .share:hover,
.quick-actions .report:hover {
  background-color: #e9ecef;
}

/* Empty States */
.empty-state {
  padding: 20px;
  text-align: center;
  color: #6c757d;
}

/* Responsive Design */
@media (max-width: 768px) {
  .container {
    flex-direction: column;
  }

  .profile-info-box {
    flex-direction: column;
    text-align: center;
  }

  .profile-details {
    margin-left: 0;
    margin-top: 20px;
  }

  .donation {
    flex-direction: column;
    text-align: center;
  }

  .donation img {
    margin-bottom: 15px;
  }
}
</style>
