<template>
  <div>
    <div class="navbar">
      <div class="navbar-logo">EduShare</div>
      <div class="navbar-links">
        <router-link to="/">Home</router-link>
        <router-link to="/browse">Browse</router-link>
        <router-link to="/about">About</router-link>
        <router-link to="/how-it-works">How It Works</router-link>
      </div>
      <div class="navbar-actions">
        <router-link to="/login">Login</router-link>
      </div>
    </div>

    <div class="filters">
      <input v-model="searchQuery" type="text" placeholder="Search for requests" />
      <select v-model="selectedResourceType">
        <option value="">All Resource Types</option>
        <option value="book">Books</option>
        <option value="laptop">Laptops</option>
        <option value="software">Software</option>
        <option value="other">Other</option>
      </select>
      <select v-model="selectedUrgency">
        <option value="">All Urgency Levels</option>
        <option value="high">High</option>
        <option value="medium">Medium</option>
        <option value="low">Low</option>
      </select>
    </div>

    <div class="requests-container">
      <div v-if="loading" class="loading">Loading requests...</div>
      <div v-else-if="error" class="error">{{ error }}</div>
      <div v-else-if="filteredRequests.length === 0" class="no-requests">No requests found.</div>

      <div v-else>
        <div v-for="request in paginatedRequests" :key="request.request_id" class="request-card">
          <div class="request-details">
            <div :class="['priority', request.urgency]">
              {{ urgencyText(request.urgency) }}
            </div>
            <div class="request-title">{{ request.title }}</div>
            <div class="request-location">
              {{ request.organization_name || 'Education Center' }}
            </div>
            <div class="request-description">
              {{ request.quantity_needed }} {{ request.resource_type }}s needed ({{
                request.condition_preference
              }}
              condition preferred)
            </div>
            <div class="request-quote">
              "Will help {{ Math.floor(request.quantity_needed * 1.5) }} students with their
              education"
            </div>
          </div>
          <div class="request-meta">
            <div class="request-time">
              {{ formatDate(request.date).text }}
              <span v-if="formatDate(request.date).showBadge" class="days-badge">
                {{ formatDate(request.date).days }}
                {{ formatDate(request.date).days === 1 ? 'day' : 'days' }}
              </span>
            </div>
            <button class="donate-button" @click="handleDonateClick(request.request_id)">
              Donate Now
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="pagination">
      <button
        v-for="page in totalPages"
        :key="page"
        :class="{ active: currentPage === page }"
        @click="changePage(page)"
      >
        {{ page }}
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const requests = ref([])
const loading = ref(true)
const error = ref(null)
const searchQuery = ref('')
const selectedResourceType = ref('')
const selectedUrgency = ref('')
const currentPage = ref(1)
const itemsPerPage = ref(5)

// Computed properties
const filteredRequests = computed(() => {
  return requests.value.filter((request) => {
    const matchesSearch = request.title.toLowerCase().includes(searchQuery.value.toLowerCase())
    const matchesResource =
      !selectedResourceType.value || request.resource_type === selectedResourceType.value
    const matchesUrgency = !selectedUrgency.value || request.urgency === selectedUrgency.value

    return matchesSearch && matchesResource && matchesUrgency
  })
})

const totalPages = computed(() => {
  return Math.ceil(filteredRequests.value.length / itemsPerPage.value)
})

const paginatedRequests = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage.value
  const end = start + itemsPerPage.value
  return filteredRequests.value.slice(start, end)
})

// Date formatting functions
const formatDate = (dateString) => {
  if (!dateString) return { text: 'Recently', showBadge: false }

  const diffDays = getDaysSince(dateString)

  if (diffDays === 0) return { text: 'Posted today', showBadge: false }
  if (diffDays === 1) return { text: 'Posted yesterday', showBadge: false }
  if (diffDays < 7) return { text: `Posted ${diffDays} days ago`, showBadge: false }

  const requestDate = new Date(dateString)
  return {
    text: requestDate.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }),
    showBadge: true,
    days: diffDays,
  }
}

const getDaysSince = (dateString) => {
  if (!dateString) return 0

  const today = new Date()
  const requestDate = new Date(dateString)

  // Reset time components to compare just dates
  today.setHours(0, 0, 0, 0)
  requestDate.setHours(0, 0, 0, 0)

  const diffTime = today - requestDate
  return Math.floor(diffTime / (1000 * 60 * 60 * 24))
}

// Other methods
const urgencyText = (urgency) => {
  const texts = {
    high: 'High Priority',
    medium: 'Medium Priority',
    low: 'Low Priority',
  }
  return texts[urgency] || 'Normal Priority'
}

const handleDonateClick = (requestId) => {
  router.push({
    name: 'matchDonations',
    params: { requestId },
  })
}

const changePage = (page) => {
  currentPage.value = page
}

// Fetch data
const fetchRequests = async () => {
  try {
    loading.value = true
    error.value = null

    const response = await fetch('http://localhost:5038/api/requests')

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    requests.value = data
  } catch (err) {
    console.error('Error fetching requests:', err)
    error.value = 'Failed to load requests. Please try again later.'
  } finally {
    loading.value = false
  }
}

// Lifecycle hook
onMounted(() => {
  fetchRequests()
})
</script>

<style scoped>
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #f5f5f5;
}
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: white;
  padding: 15px 30px;
  border-bottom: 1px solid #ddd;
}
.navbar-logo {
  display: flex;
  align-items: center;
  font-size: 24px;
  font-weight: bold;
  color: #007bff;
}
.navbar-logo::before {
  content: '🎓';
  margin-right: 5px;
}
.navbar-links {
  display: flex;
  gap: 20px;
}
.navbar-links a {
  text-decoration: none;
  color: #333;
  font-size: 16px;
}
.navbar-actions {
  display: flex;
  gap: 10px;
}
.navbar-actions a {
  text-decoration: none;
  color: #333;
  font-size: 16px;
}
.filters {
  display: flex;
  justify-content: center;
  gap: 20px;
  padding: 20px;
  background-color: white;
  border-bottom: 1px solid #ddd;
}
.filters input,
.filters select {
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 14px;
}
.filters input {
  width: 300px;
}
.requests-container {
  max-width: 800px;
  margin: 20px auto;
}
.request-card {
  background-color: white;
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}
.request-details {
  flex: 1;
}
.priority {
  padding: 5px 10px;
  border-radius: 15px;
  font-size: 12px;
  font-weight: bold;
  margin-bottom: 10px;
  display: inline-block;
}
.priority.high {
  background-color: #ffe6e6;
  color: #ff3333;
}
.priority.medium {
  background-color: #fff3e0;
  color: #ff9800;
}
.priority.low {
  background-color: #e6ffe6;
  color: #4caf50;
}
.request-title {
  font-size: 18px;
  font-weight: bold;
  margin: 5px 0;
}
.request-location {
  font-size: 14px;
  color: #666;
  margin-bottom: 5px;
}
.request-description {
  font-size: 14px;
  color: #333;
  margin-bottom: 10px;
}
.request-quote {
  font-size: 14px;
  color: #666;
  font-style: italic;
  margin-bottom: 10px;
}
.request-meta {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 10px;
}
.request-time {
  font-size: 12px;
  color: #666;
  display: flex;
  align-items: center;
}
.days-badge {
  background-color: #f0f0f0;
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 0.8em;
  margin-left: 6px;
  color: #555;
}
.donate-button {
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.2s;
}
.donate-button:hover {
  background-color: #0069d9;
}
.pagination {
  display: flex;
  justify-content: center;
  gap: 10px;
  padding: 20px;
}
.pagination button {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 8px 12px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
}
.pagination button.active {
  background-color: #0056b3;
}
.loading,
.error,
.no-requests {
  text-align: center;
  padding: 40px;
  font-size: 18px;
  color: #666;
}
.error {
  color: #dc3545;
}
</style>
