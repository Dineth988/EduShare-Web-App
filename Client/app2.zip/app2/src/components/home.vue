<style scoped>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Inter-Regular', Helvetica, sans-serif;
  color: #ffffff;
}

/* Hero Section */
.FRAME {
  width: 100%;
  min-height: 600px;
  background:
    linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)),
    /* Dark overlay */
      url('https://img.freepik.com/premium-photo/girl-writing-blackboard-classroom_1048944-25950159.jpg')
      center/cover no-repeat;
  display: flex;
  justify-content: center;
  padding: 0 120px;
}

.FRAME .div {
  width: 100%;
  max-width: 1200px;
  height: 600px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  position: relative;
}

.MARGIN-WRAPPER {
  width: 100%;
  max-width: 926px;
  margin-bottom: 20px;
}

.FRAME .labels-wrapper {
  width: 100%;
}

.FRAME .labels {
  font-size: 60px;
  line-height: 1.2;
  font-weight: 400;
  color: #ffffff;
  margin-bottom: 16px;
}

.FRAME .FRAME-wrapper {
  width: 100%;
  max-width: 638px;
  margin-bottom: 40px;
}

.FRAME .text-wrapper {
  font-size: 20px;
  line-height: 1.4;
  font-weight: 400;
  color: #ffffff;
}

.FRAME .labels-wrapper-2 {
  width: 177px;
  height: 56px;
  background-color: #2462eb;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.FRAME .labels-wrapper-2:hover {
  background-color: #1a4fc8;
}

.FRAME .labels-2 {
  font-size: 16px;
  font-weight: 400;
  color: #ffffff;
}

/* Stats Section */
.FRAME1 {
  width: 100%;
  min-height: 308px;
  background-color: #f8f9fb;
  display: flex;
  justify-content: center;
  padding: 80px 120px;
}

.FRAME1 .div1 {
  width: 100%;
  max-width: 1200px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 32px;
}

.FRAME1 .div-2,
.FRAME1 .div-3,
.FRAME1 .div-4,
.FRAME1 .div-5 {
  flex: 1;
  min-width: 200px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 20px 0;
}

.FRAME1 .img,
.FRAME1 .img-2 {
  width: 48px;
  height: 48px;
  margin-bottom: 16px;
}

.FRAME1 .img-2 {
  height: 48px;
}

.FRAME1 .labels,
.FRAME1 .labels-2,
.FRAME1 .labels-4,
.FRAME1 .labels-6 {
  font-size: 48px;
  line-height: 1.2;
  font-weight: 400;
  color: #111826;
  margin-bottom: 8px;
}

.FRAME1 .text-wrapper,
.FRAME1 .labels-3,
.FRAME1 .labels-5,
.FRAME1 .labels-7 {
  font-size: 18px;
  line-height: 1.5;
  font-weight: 400;
  color: #4b5462;
}

/* Responsive Adjustments */
@media (max-width: 1024px) {
  .FRAME,
  .FRAME1 {
    padding: 0 60px;
  }

  .FRAME .labels {
    font-size: 48px;
  }

  .FRAME1 .div1 {
    gap: 24px;
  }
}

@media (max-width: 768px) {
  .FRAME,
  .FRAME1 {
    padding: 0 32px;
  }

  .FRAME .div {
    height: auto;
    padding: 100px 0;
  }

  .FRAME .labels {
    font-size: 36px;
  }

  .FRAME .text-wrapper {
    font-size: 18px;
  }

  .FRAME1 .div1 {
    flex-direction: column;
    align-items: center;
  }

  .FRAME1 .div-2,
  .FRAME1 .div-3,
  .FRAME1 .div-4,
  .FRAME1 .div-5 {
    width: 100%;
    max-width: 300px;
  }
}

@media (max-width: 480px) {
  .FRAME .labels {
    font-size: 28px;
  }

  .FRAME .text-wrapper {
    font-size: 16px;
  }

  .FRAME1 .labels,
  .FRAME1 .labels-2,
  .FRAME1 .labels-4,
  .FRAME1 .labels-6 {
    font-size: 36px;
  }

  .FRAME1 .text-wrapper,
  .FRAME1 .labels-3,
  .FRAME1 .labels-5,
  .FRAME1 .labels-7 {
    font-size: 16px;
  }
}

.how-it-works-frame {
  width: 1440px;
  height: 480px;
  background-color: #ffffff;
}

.how-it-works-container {
  position: relative;
  width: 1200px;
  height: 288px;
  margin: 96px auto 0;
}

.how-it-works-title-wrapper {
  position: absolute;
  width: 100%;
  height: 40px;
  top: 0;
  left: 0;
}

.how-it-works-title {
  width: 234px;
  margin: 0 auto;
  color: #111826;
  font-size: 36px;
  line-height: 40px;
  font-family: 'Inter-Regular', Helvetica;
  font-weight: 400;
  text-align: center;
}

.steps-container {
  position: absolute;
  width: 100%;
  height: 184px;
  top: 104px;
  left: 40px;
  display: flex;
  justify-content: space-between;
}

.step-1,
.step-2,
.step-3 {
  width: 368px;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.step-icon-wrapper {
  width: 64px;
  height: 64px;
  background-color: #2462eb;
  border-radius: 9999px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 24px;
}

.step-icon {
  width: 32px;
  height: 32px;
}

.step-title-wrapper {
  width: 100%;
  margin-bottom: 16px;
}

.step-title {
  color: #111826;
  font-size: 24px;
  line-height: 32px;
  font-family: 'Inter-Regular', Helvetica;
  font-weight: 400;
  text-align: center;
}

.step-description-wrapper {
  width: 100%;
}

.step-description {
  color: #4b5462;
  font-size: 16px;
  line-height: 24px;
  font-family: 'Inter-Regular', Helvetica;
  font-weight: 400;
  text-align: center;
  max-width: 316px;
  margin: 0 auto;
}
.featured-donations-section {
  width: 100%;
  padding: 60px 0;
  background-color: #ffffff;
}

.featured-donations-container {
  width: 90%;
  max-width: 1200px;
  margin: 0 auto;
}

.section-title-wrapper {
  text-align: center;
  margin-bottom: 40px;
}

.section-title {
  color: #111826;
  font-size: 36px;
  font-family: 'Inter-Regular', Helvetica;
  font-weight: 400;
}

.donation-cards-container {
  display: flex;
  justify-content: space-around;
  gap: 30px;
}

.donation-card-1,
.donation-card-2,
.donation-card-3 {
  width: 30%;
  max-width: 380px;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
}

.donation-card-1:hover,
.donation-card-2:hover,
.donation-card-3:hover {
  transform: translateY(-5px);
}

/* Success Stories Section */
.success-stories-section {
  padding: 80px 0;
  background-color: #f8f9fb;
}

.success-stories-container {
  width: 90%;
  max-width: 1200px;
  margin: 0 auto;
}

.success-stories-title {
  text-align: center;
  font-size: 36px;
  color: #111826;
  margin-bottom: 50px;
  font-family: 'Inter-Regular', Helvetica;
}

.story-cards-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
}

.story-card {
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
}

.story-card:hover {
  transform: translateY(-5px);
}

.story-image-wrapper {
  height: 200px;
  overflow: hidden;
}

.story-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.5s ease;
}

.story-card:hover .story-image {
  transform: scale(1.05);
}

.story-content {
  padding: 25px;
}

.story-description {
  color: #4b5462;
  line-height: 1.6;
  margin-bottom: 15px;
  font-size: 16px;
}

/* Footer Styles */
.site-footer {
  background-color: #000000;
  color: #ffffff;
  padding: 60px 0 20px;
  font-family: 'Inter-Regular', Helvetica, sans-serif;
}

.footer-container {
  width: 90%;
  max-width: 1200px;
  margin: 0 auto;
}

.footer-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 40px;
  margin-bottom: 40px;
}

.footer-column {
  margin-bottom: 30px;
}

.footer-heading {
  color: #ffffff;
  font-size: 18px;
  margin-bottom: 20px;
  position: relative;
  padding-bottom: 10px;
}

.footer-heading::after {
  content: '';
  position: absolute;
  left: 0;
  bottom: 0;
  width: 50px;
  height: 2px;
  background-color: #2462eb;
}

.footer-about {
  color: #b3b3b3;
  line-height: 1.6;
  margin-bottom: 20px;
  font-size: 14px;
}

.footer-links {
  list-style: none;
}

.footer-links li {
  margin-bottom: 12px;
}

.footer-links a {
  color: #b3b3b3;
  text-decoration: none;
  transition: color 0.3s ease;
  font-size: 14px;
}

.footer-links a:hover {
  color: #ffffff;
}

.footer-contact {
  list-style: none;
  color: #b3b3b3;
  font-size: 14px;
}

.footer-contact li {
  margin-bottom: 15px;
  display: flex;
  align-items: center;
}

.footer-contact i {
  margin-right: 10px;
  color: #2462eb;
  width: 20px;
  text-align: center;
}

.social-links {
  display: flex;
  gap: 15px;
}

.social-links a {
  color: #ffffff;
  background-color: #333333;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.social-links a:hover {
  background-color: #2462eb;
  transform: translateY(-3px);
}

.footer-bottom {
  border-top: 1px solid #333333;
  padding-top: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.copyright {
  color: #b3b3b3;
  font-size: 12px;
  margin-bottom: 10px;
}

.legal-links {
  display: flex;
  gap: 20px;
}

.legal-links a {
  color: #b3b3b3;
  text-decoration: none;
  font-size: 12px;
  transition: color 0.3s ease;
}

.legal-links a:hover {
  color: #ffffff;
}

/* Font Awesome Icons (add this to your head tag) */

/* Responsive adjustments */
@media (max-width: 768px) {
  .footer-grid {
    grid-template-columns: 1fr 1fr;
  }

  .footer-bottom {
    flex-direction: column;
  }
}

@media (max-width: 480px) {
  .footer-grid {
    grid-template-columns: 1fr;
  }
}
.featured-donations-section {
  padding: 40px 0;
  background-color: #f9f9f9;
  width: 100%;
  overflow-x: hidden;
}

.featured-donations-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.section-title {
  text-align: center;
  margin-bottom: 30px;
  color: #333;
}

.donation-cards-scroll-container {
  width: 100%;
  overflow-x: auto;
  padding-bottom: 20px; /* Space for scrollbar */
}

.donation-cards-container {
  display: inline-flex;
  gap: 20px;
  padding: 10px 0;
}

.donation-card {
  flex: 0 0 auto;
  width: 250px;
  height: 350px;
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 15px;
  text-align: center;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  transition: transform 0.3s ease;
  text-align: center;
}

.donation-card:hover {
  transform: translateY(-5px);
}

.donation-card img {
  width: 250px;
  height: 150px;
  object-fit: cover;
  border-radius: 4px;
}

.donate-now-button {
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.donate-now-button:hover {
  background-color: #0056b3;
}

/* Hide scrollbar but keep functionality */
.donation-cards-scroll-container::-webkit-scrollbar {
  height: 8px;
}

.donation-cards-scroll-container::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 10px;
}

.donation-cards-scroll-container::-webkit-scrollbar-thumb {
  background: #888;
  border-radius: 10px;
}

.donation-cards-scroll-container::-webkit-scrollbar-thumb:hover {
  background: #555;
}
</style>

<template>
  <div class="FRAME">
    <div class="div">
      <div class="MARGIN-WRAPPER">
        <div class="labels-wrapper"><div class="labels">Empower Learners Everywhere</div></div>
      </div>
      <div class="FRAME-wrapper">
        <div class="div-wrapper">
          <p class="text-wrapper">
            Connecting donors with communities to make education accessible
          </p>
        </div>
      </div>
      <div class="labels-wrapper-2">
        <div class="labels-2">
          <a href="/requests" style="text-decoration: none; color: aliceblue">Start Donating</a>
        </div>
      </div>
    </div>
  </div>
  <div class="FRAME1">
    <div class="div1">
      <div class="div-2">
        <img
          class="img"
          src="https://img.icons8.com/?size=100&id=bwUgs69v7bOd&format=png&color=000000"
        />
        <div class="labels-wrapper"><div class="labels">10,000+</div></div>
        <div class="div-wrapper"><div class="text-wrapper">Books Donated</div></div>
      </div>
      <div class="div-3">
        <img
          class="img-2"
          src="https://img.icons8.com/?size=100&id=7rmNtCYhDvvG&format=png&color=000000"
        />
        <div class="labels-wrapper"><div class="labels-2">500+</div></div>
        <div class="div-wrapper"><div class="labels-3">Schools Supported</div></div>
      </div>
      <div class="div-4">
        <img class="img-2" src="https://img.icons8.com/?size=100&id=7Iw01uG13raK&format=png&color=000000" />
        <div class="labels-wrapper"><div class="labels-4">5,000+</div></div>
        <div class="div-wrapper"><div class="labels-5">Active Donors</div></div>
      </div>
      <div class="div-5">
        <img class="img" src="https://img.icons8.com/?size=100&id=mTs9S7DfoHiE&format=png&color=000000" />
        <div class="labels-wrapper"><div class="labels-6">25+</div></div>
        <div class="div-wrapper"><div class="labels-7">Countries Reached</div></div>
      </div>
    </div>
  </div>
  <div class="how-it-works-frame">
    <div class="how-it-works-container">
      <div class="how-it-works-title-wrapper">
        <div class="how-it-works-title">How It Works</div>
      </div>
      <div class="steps-container">
        <div class="step-1">
          <div class="step-icon-wrapper"><img class="step-icon" src="https://img.icons8.com/?size=100&id=37917&format=png&color=000000" /></div>
          <div class="step-title-wrapper"><div class="step-title">List Resources</div></div>
          <div class="step-description-wrapper">
            <p class="step-description">Share what educational materials you can donate</p>
          </div>
        </div>
        <div class="step-2">
          <div class="step-icon-wrapper"><img class="step-icon" src="https://img.icons8.com/?size=100&id=2727&format=png&color=000000" /></div>
          <div class="step-title-wrapper"><div class="step-title">Get Matched</div></div>
          <div class="step-description-wrapper">
            <p class="step-description">Connect with schools and communities in need</p>
          </div>
        </div>
        <div class="step-3">
          <div class="step-icon-wrapper"><img class="step-icon" src="https://img.icons8.com/?size=100&id=Atb5mR0Y5hAu&format=png&color=000000" /></div>
          <div class="step-title-wrapper"><div class="step-title">Deliver or Collect</div></div>
          <div class="step-description-wrapper">
            <p class="step-description">Coordinate the transfer of resources</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="featured-donations-section">
    <div class="featured-donations-container">
      <div class="section-title-wrapper">
        <h2 class="section-title">Featured Donations</h2>
      </div>
      <div
        class="donation-cards-container"
        id="donationCardsContainer"
        style="display: flex; flex-direction: row; gap: 20px"
      >
        <!-- Cards will be dynamically inserted here -->
      </div>
    </div>
  </div>
  <!-- Success Stories Section -->
  <section class="success-stories-section">
    <div class="success-stories-container">
      <h2 class="success-stories-title">Our Success Stories</h2>

      <div class="story-cards-container">
        <!-- Story Card 1 -->
        <div class="story-card">
          <div class="story-image-wrapper">
            <img src="https://th.bing.com/th/id/R.06b723685da98151db172b57ab743b5e?rik=ydGOlEGECxhLMw&pid=ImgRaw&r=0" alt="Students reading donated books" class="story-image" />
          </div>
          <div class="story-content">
            <p class="story-description">
              Thanks to generous donations, we've provided over 5,000 books to rural schools,
              helping children discover the joy of reading.
            </p>
            <div class="story-recipient">Recipient: <span>Greenwood Elementary</span></div>
            <a href="#" class="read-more-btn">Read More</a>
          </div>
        </div>

        <!-- Story Card 2 -->
        <div class="story-card">
          <div class="story-image-wrapper">
            <img src="https://pc24telin.com/wp-content/uploads/2019/12/Computer-Lab-schools.jpg" alt="School computer lab" class="story-image" />
          </div>
          <div class="story-content">
            <p class="story-description">
              Our technology drive equipped 3 schools with modern computer labs, bridging the
              digital divide for 1,200 students.
            </p>
            <div class="story-recipient">Recipient: <span>Sunrise Community School</span></div>
            <a href="#" class="read-more-btn">Read More</a>
          </div>
        </div>

        <!-- Story Card 3 -->
        <div class="story-card">
          <div class="story-image-wrapper">
            <img src="https://www.school-news.com.au/wp-content/uploads/2023/01/Handfuls-780x470.jpg" alt="Teacher with supplies" class="story-image" />
          </div>
          <div class="story-content">
            <p class="story-description">
              Classroom supply donations helped 45 teachers get the materials they needed for
              effective teaching this semester.
            </p>
            <div class="story-recipient">
              Recipient: <span>Maplewood Teachers Association</span>
            </div>
            <a href="#" class="read-more-btn">Read More</a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Footer Section -->
  <footer class="site-footer">
    <div class="footer-container">
      <div class="footer-grid">
        <!-- Column 1: About -->
        <div class="footer-column">
          <h3 class="footer-heading">About EduShare</h3>
          <p class="footer-about">
            Connecting donors with communities to make education accessible for all learners
            worldwide.
          </p>
          <div class="social-links">
            <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
            <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
            <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
          </div>
        </div>

        <!-- Column 2: Quick Links -->
        <div class="footer-column">
          <h3 class="footer-heading">Quick Links</h3>
          <ul class="footer-links">
            <li><a href="#">Home</a></li>
            <li><a href="#">How It Works</a></li>
            <li><a href="#">Donate Now</a></li>
            <li><a href="#">Success Stories</a></li>
            <li><a href="#">Volunteer</a></li>
          </ul>
        </div>

        <!-- Column 3: Resources -->
        <div class="footer-column">
          <h3 class="footer-heading">Resources</h3>
          <ul class="footer-links">
            <li><a href="#">Blog</a></li>
            <li><a href="#">FAQ</a></li>
            <li><a href="#">School Resources</a></li>
            <li><a href="#">Donor Toolkit</a></li>
            <li><a href="#">Annual Report</a></li>
          </ul>
        </div>

        <!-- Column 4: Contact -->
        <div class="footer-column">
          <h3 class="footer-heading">Contact Us</h3>
          <ul class="footer-contact">
            <li><i class="fas fa-map-marker-alt"></i> 123 Education Ave, Learn City 10001</li>
            <li><i class="fas fa-phone"></i> (123) 456-7890</li>
            <li><i class="fas fa-envelope"></i> info@edushare.org</li>
          </ul>
        </div>
      </div>

      <!-- Copyright -->
      <div class="footer-bottom">
        <p class="copyright">&copy; 2023 EduShare. All rights reserved.</p>
        <div class="legal-links">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms of Service</a>
          <a href="#">Cookie Policy</a>
        </div>
      </div>
    </div>
  </footer>
</template>

<script setup>
// Function to fetch and display featured donations
async function fetchFeaturedDonations() {
  try {
    const response = await fetch('http://localhost:5038/api/featured-donations')
    if (!response.ok) {
      throw new Error('Network response was not ok')
    }
    const donations = await response.json()
    displayDonations(donations)
  } catch (error) {
    console.error('Error fetching featured donations:', error)
    // Display error or fallback content
    document.getElementById('donationCardsContainer').innerHTML =
      '<p>Unable to load featured donations at this time.</p>'
  }
}

// Function to display donations in the UI
function displayDonations(donations) {
  const container = document.getElementById('donationCardsContainer')
  container.innerHTML = '' // Clear any existing content

  donations.forEach((donation) => {
    const card = document.createElement('div')
    card.className = 'donation-card'
    card.style =
      'width: 250px; height: 350px; border: 1px solid #ccc; border-radius: 8px; padding: 15px; text-align: center; box-shadow: 0 4px 8px rgba(0,0,0,0.1); display: flex; flex-direction: column; justify-content: space-between;'

    card.innerHTML = `
        <img src="${donation.image_link}" alt="${donation.title}" style="width: 249px; height: 150px; object-fit: cover; border-radius: 4px;" />
        <div style="display: flex; flex-direction: column; gap: 10px;">
          <h3 class="resource-name" style="margin: 10px 0; font-size: 18px; color: black;">${donation.title}</h3>
          <p style="margin: 0; font-size: 14px; color: #555;">Type: ${donation.type}</p>
          <p style="margin: 0; font-size: 14px; color: #555;">Condition: ${donation.condition}</p>
          <button class="donate-now-button" style="background-color: #007BFF; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">Donate Now</button>
        </div>
      `

    container.appendChild(card)
  })
}

// Fetch donations when the page loads
document.addEventListener('DOMContentLoaded', fetchFeaturedDonations)
</script>
