import { createRouter, createWebHistory } from 'vue-router'

import Profile from '@/components/profile.vue'
import Requests from '@/components/requests.vue'
import Home from '@/components/home.vue'
import Donation from '@/components/donation.vue'
import MatchDonations from '@/components/matchDonations.vue'
import MoneyDonations from '@/components/moneyDonations.vue'
import ServiceDonation from '@/components/serviceDonation.vue'
import Denethifile from '@/components/denethifile.vue'
import Resourceupdate_denethi from '@/components/resourceupdate_denethi.vue'
import Awshadiadmin from '@/components/awshadiadmin.vue'
import Login from '@/components/login.vue'
import ThankDonationPage from '@/components/thankDonationPage.vue'
import Register from '@/components/register.vue'
import Chat from '@/components/chat.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/profile',
      name: 'profile',
      component: Profile,
    },
    {
      path: '/requests',
      name: 'requests',
      component: Requests,
    },
    {
      path: '/home',
      name: 'home',
      component: Home,
    },
    {
      path: '/donation',
      name: 'donation',
      component: Donation,
    },
    {
      path: '/matchDonations/:requestId',
      name: 'matchDonations',
      component: MatchDonations,
    },
    {
      path: '/moneyDonations',
      name: 'moneyDonations',
      component: MoneyDonations,
    },
    {
      path: '/serviceDonation',
      name: 'serviceDonation',
      component: ServiceDonation,
    },
    {
      path: '/denethi',
      name: 'denethi',
      component: Denethifile,
    },
    {
      path: '/resup',
      name: 'resup',
      component: Resourceupdate_denethi,
    },
    {
      path: '/awshadiad',
      name: 'awshadiad',
      component: Awshadiadmin,
    },
    {
      path: '/login',
      name: 'login',
      component: Login,
    },
    {
      path: '/thankDonation/:donationId',
      name: 'thankDonation',
      component: ThankDonationPage,
      props: true,
    },
    {
      path: '/register',
      name: 'register',
      component: Register,
      props: true,
    },
     {
      path: '/chat',
      name: 'chat',
      component: Chat,
      props: true,
    },
  ],
})

export default router
