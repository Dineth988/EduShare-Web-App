<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'

</script>

<template>
  <header>
      <nav>
       
      </nav>
  </header>

  <RouterView />
</template>
