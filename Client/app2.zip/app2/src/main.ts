
import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

const app = createApp(App)


// Declare global user properties
declare module '@vue/runtime-core' {
  interface ComponentCustomProperties {
    $currentUser: {
      id: string | null
      email: string | null
      role: string | null
    }
  }
}

// Initialize global user object
app.config.globalProperties.$currentUser = {
  id: null,
  email: null,
  role: null
}

app.use(router)

app.mount('#app')



